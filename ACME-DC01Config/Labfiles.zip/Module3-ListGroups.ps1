﻿# Replace variables
#Variables
$TenantId = "07e6903b-72a7-40d3-b94e-6aea489a03e8"
$ApplicationId = "548be7f7-8b84-4ef5-aa0d-c67c1266da27"
$Thumbprint = "4D64BDF0991D396FA2AF528F991944B8830F7AA2"

#Connect to AzureAD
Try {
    Write-Output 'Connecting to services'
    Connect-AzAccount -ApplicationId $ApplicationId -Tenant $TenantId -CertificateThumbprint $Thumbprint
    }
Catch {
    Write-Error -Message $_.Exception.Message
    #Hangup
    Disconnect-AzAccount | Out-null
    Break
}
Write-Output "Connect process done"
# Function
try {
    Write-Output 'List all groups'
    $groups = Get-AzADGroup
    Write-Output $groups.Displayname | Out-File C:\temp\AutomationWorkflow2023.txt
    
}
Catch {
    Write-Error -Message $_.Exception.Message
    #Hangup
    Disconnect-AzAccount | Out-null
}
