﻿#Installera Azure MGGraph modulen
Install-Module Microsoft.Graph
Connect-MgGraph -Scopes "User.ReadWrite.All","Domain.ReadWrite.All"

$DomainName = Get-ADForest | select upnsuffixes -ExpandProperty upnsuffixes

New-MgDomain -BodyParameter @{Id="$($DomainName)";IsDefault="True"}
$verificationTXT = (Get-MgDomainVerificationDnsRecord -DomainId "$($DomainName)" | Where-Object {$_.RecordType -eq "Txt"}).AdditionalProperties.text

$ResourceGroup = (Get-AzResourceGroup |where resourcegroupname -like M365*).ResourceGroupName

#Add records to DNS
$Records = @()
$Records += New-AzDnsRecordConfig -Value $verificationTXT
$RecordSet = New-AzDnsRecordSet -Name "@" -RecordType TXT -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$MXDomain = $DomainName.Replace(".","-")
$MX = $MXDomain + ".mail.protection.outlook.com"

$Records = @()
$Records += New-AzDnsRecordConfig -Cname EnterpriseEnrollment-s.manage.microsoft.com
$RecordSet = New-AzDnsRecordSet -Name "EnterpriseEnrollment" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzDnsRecordConfig -Cname EnterpriseRegistration.windows.net
$RecordSet = New-AzDnsRecordSet -Name "EnterpriseRegistration" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzDnsRecordConfig -Cname clientconfig.microsoftonline-p.net
$RecordSet = New-AzDnsRecordSet -Name "MSOID" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzDnsRecordConfig -Cname autodiscover.outlook.com
$RecordSet = New-AzDnsRecordSet -Name "autodiscover" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzDnsRecordConfig -Cname sipdir.online.lync.com
$RecordSet = New-AzDnsRecordSet -Name "sip" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzDnsRecordConfig -Cname webdir.online.lync.com
$RecordSet = New-AzDnsRecordSet -Name "lyncdiscover" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzDnsRecordConfig -Exchange $MX -Preference 10
$RecordSet = New-AzDnsRecordSet -Name "@" -RecordType MX -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzDnsRecordConfig -Priority 100 -Weight 1 -Port 443 -Target sipdir.online.lync.com
$RecordSet = New-AzDnsRecordSet -Name "_sip._tls" -RecordType SRV -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzDnsRecordConfig -Priority 100 -Weight 1 -Port 5061 -Target sipfed.online.lync.com
$RecordSet = New-AzDnsRecordSet -Name "_sipfederationtls._tcp" -RecordType SRV -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$RecordSet = Get-AzDnsRecordSet -Name "@" -RecordType TXT -ResourceGroupName $ResourceGroup -ZoneName $DomainName
Add-AzDnsRecordConfig -RecordSet $RecordSet -Value "v=spf1 include:spf.protection.outlook.com -all"
Set-AZDnsRecordSet -RecordSet $RecordSet

    DO
    {
    Write-Host "Domain is not verified yet, please wait" -ForegroundColor Red
    Start-Sleep -Seconds 20
    Confirm-MgDomain -DomainId "$($DomainName)"
    $verificationstatus = Get-MgDomain -DomainId $($DomainName) | select IsVerified -ExpandProperty IsVerified
    } Until ($verificationstatus -eq $true)

Update-MgDomain -DomainId $domainname -BodyParameter @{IsDefault="False"}
Write-Host "Domain is verified and set as default, DNS Config will continue" -ForegroundColor Green